import 'package:dartlessonhomework3/dartlessonhomework3.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
