import 'package:dartlessonhomework2/dartlessonhomework2.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
